<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <title>Inventario | San Francisco</title>
</head>
<body>
<?php
session_start();
if($_SESSION['Correo']==null && $_SESSION['Correo']=='')
{
   header("Location:../index.php");
}
?>
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <B>EMPLEADO</B><br><br>(<?php echo $_SESSION['Correo']; ?>)
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="/Inventario/view/venta.php">VENTAS</a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="/Inventario/view/salir.php">CERRAR SESSION</a>
        </li>
      </ul>
    </div>
  </nav>
<br>
  <!-- Resto del contenido de la página -->