<?php
error_reporting(0);
require_once('../controllers/conexion.php');
include('../master/header.php');

$Id_Categoria = $_GET['Id_Categoria'];
$Nombre_Categoria = $_GET['Nombre_Categoria'];
?>

<div class="container">
    <main>
        <div class="row">
            <div class="text-center">
                <h5>ACTUALIZAR CATEGORIA</h5>
            </div>
           
            <div class="col-12">
                <div class="row justify-content-center align-content-center text-center">
                    
                    <form action="../controllers/EditCategoria.php" method="POST">
                    <input type="text" class="form-control" id="Id_Categoria" name="Id_Categoria" placeholder="" style="visibility: hidden"; value="<?=$Id_Categoria?>">
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Nombre de la Categoria:</label>
                            <input type="text" class="form-control" id="Nombre_Categoria" name="Nombre_Categoria" placeholder="" value="<?=$Nombre_Categoria?>">
                        </div>      
                                    
                        <button type="submit" class="btn btn-primary">Actualizar Categoria</button>
                        <a href="categorias.php" class="btn btn-danger">Regresar</a>
                    </form>

                    <?php
                        if(isset($_SESSION['message']))
                        {
                            echo "<h4>".$_SESSION['message']."</h4>";
                            unset($_SESSION['message']);
                        }
                    ?>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>