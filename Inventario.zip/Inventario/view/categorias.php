<?php
require_once('../controllers/conexion.php');
include('../master/header.php');
?>

<div class="container">
    <main>
        <div class="row">
            <div class="col-12">
                <div class="row justify-content-center align-content-center text-center">
                    
                    <div class="card">
                        <div class="card-header">
                            CATEGORIAS
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-secondary">
                                    <thead>
                                        <tr>
                                            <th scope="col">ID</th>
                                            <th scope="col">Nombre de la Categoria</th>
                                            <th scope="col">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                        $sql = "SELECT Id_Categoria, Nombre_Categoria FROM categoria";
                                        $rta = mysqli_query($conexion, $sql);
                                        while ($mostrar = mysqli_fetch_row($rta)){
                                    ?>
                                        <tr>
                                            <th> <?php echo $mostrar["0"] ?> </th>
                                            <td><?php echo $mostrar["1"] ?></td>
                                            <td>
                                                <a
                                                href="EditCategoria.php? 
                                                Id_Categoria=<?php echo $mostrar['0'] ?> &
                                                Nombre_Categoria=<?php echo $mostrar['1'] ?>" 
                                                class="btn btn-success">Editar</a>
                                                <a href="../controllers/deletecategoria.php?Id_Categoria=<?php echo $mostrar['0'] ?>" class="btn btn-danger">Eliminar</a>
                                            </td>    
                                        </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                        <div class="card-footer text-muted">
                            <a href="Addcategoria.php" class="btn btn-primary">Nuevo</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>