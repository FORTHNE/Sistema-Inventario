<?php
require_once('../controllers/conexion.php');
include('../master/headerEmpl.php');
?>
<div class="container">
    <h3 class="text-center">PRODUCTOS DISPONIBLES</h3>
    <hr>
</div>
<div class="container mt-5">
    <main>
        <div class="row">
        <a class="btn btn-warning float-left" href="AddVenta.php">AGREGAR VENTAS</a>
        <a class="btn btn-success float-left" href="contabilidad.php">CALCULAR VENTAS</a>
        <br>
            <div class="col-12">
                <br>
                <div class="row justify-content-center align-content-center text-center">
                    <br>
                <table class="table table-dark">
                    <thead>
                        <tr>
                        <th scope="col">N°</th>
                        <th scope="col">Producto</th>
                        <th scope="col">Cantidad Disponible</th>
                        <th scope="col">Precio</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php 
                    $sql = "SELECT productos.id_producto, productos.nombre_producto, productos.cantidad_disponible, productos.precio_unitario FROM productos 
                    WHERE productos.Estado='Disponible'";
                    $rta = mysqli_query($conexion, $sql);
                    while ($mostrar = mysqli_fetch_row($rta)){
                    ?>
                        <tr>
                            <th> <?php echo $mostrar["0"] ?> </th>
                            <td><?php echo $mostrar["1"] ?></td>
                            <td><?php echo $mostrar["2"] ?></td>
                            <td>$<?php echo $mostrar["3"] ?></td>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                </table>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>