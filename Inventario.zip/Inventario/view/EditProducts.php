<?php
error_reporting(0);
require_once('../controllers/conexion.php');
include('../master/header.php');

$id_producto  = $_GET['id_producto'];
$nombre_producto = $_GET['nombre_producto'];
$cantidad_disponible = $_GET['cantidad_disponible'];
$precio_unitario = $_GET['precio_unitario'];
$proveedor_id = $_GET['proveedor_id'];
$Id_Categoria = $_GET['Id_Categoria'];
$Estado = $_GET['Estado'];

?>

<div class="container">
    <main>
        <div class="row">
            <div class="text-center">
                <h5>ACTUALIZAR PRODUCTO</h5>
            </div>
           
            <div class="col-12">
                <div class="row justify-content-center align-content-center text-center">
                    
                    <form action="../controllers/EditsProduct.php" method="POST">
                    <input type="text" class="form-control" id="id_producto" name="id_producto" placeholder="" style="visibility: hidden"; value="<?=$id_producto?>" required>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Nombre del Producto:</label>
                            <input type="text" class="form-control" id="nombre_producto" name="nombre_producto" placeholder="" value="<?=$nombre_producto?>" required>
                        </div>     
                        
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Cantidad Disponible:</label>
                            <input type="text" class="form-control" id="cantidad_disponible" name="cantidad_disponible" placeholder="" value="<?=$cantidad_disponible?>" required>
                        </div> 

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Precio Unitario:</label>
                            <input type="text" class="form-control" id="precio_unitario" name="precio_unitario" placeholder="" value="<?=$precio_unitario?>" required>
                        </div> 

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Proveedor del Producto:</label>
                            <select class="form-select" aria-label="Default select example" name="proveedor_id">
                                    <?php
                                        $query="SELECT * FROM proveedor";
                                        $result=mysqli_query($conexion, $query) or die (mysqli_error());
                                        while ($row=mysqli_fetch_array($result)){
                                        echo '<option value="'.$row['id_proveedor'].'">'.$row['nombre_proveedor'].'</option>';
                                        }
                                    ?>
                            </select>
                        </div> 

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Categoria del Producto:</label>
                            <select class="form-select" aria-label="Default select example" name="Id_Categoria">
                                    <?php
                                        $query="SELECT  * FROM categoria";
                                        $result=mysqli_query($conexion, $query) or die (mysqli_error());
                                        while ($row=mysqli_fetch_array($result)){
                                        echo '<option value="'.$row['Id_Categoria'].'">'.$row['Nombre_Categoria'].'</option>';
                                        }
                                    ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Estado del Producto:</label>
                            <select class="form-select" aria-label="Default select example" name="Estado">
                                <option value="Disponible">Disponible</option>
                                <option value="Terminado">Terminado</option>
                            </select>
                        </div>
                                    
                        <button type="submit" class="btn btn-primary">Actualizar Producto</button>
                        <a href="productos.php" class="btn btn-danger">Regresar</a>
                    </form>

                    <?php
                        if(isset($_SESSION['message']))
                        {
                            echo "<h4>".$_SESSION['message']."</h4>";
                            unset($_SESSION['message']);
                        }
                    ?>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>