<?php
require_once('../controllers/conexion.php');
include('../master/header.php');
?>

<div class="container">
    <main>
        <div class="row">
            <div class="text-center">
                <h5>AGREGAR CATEGORIA</h5>
            </div>
           
            <div class="col-12">
                <div class="row justify-content-center align-content-center text-center">
                    
                    <form action="../controllers/AddCategoria.php " method="POST">
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Nombre de la Categoria:</label>
                            <input type="text" class="form-control" id="Nombre_Categoria" name="Nombre_Categoria" placeholder="" required>
                        </div>      
                                    
                        <button type="submit" class="btn btn-primary">Agregar Categoria</button>
                        <a href="categorias.php" class="btn btn-danger">Regresar</a>
                    </form>

                    <?php
                        if(isset($_SESSION['message']))
                        {
                            echo "<h4>".$_SESSION['message']."</h4>";
                            unset($_SESSION['message']);
                        }
                    ?>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>