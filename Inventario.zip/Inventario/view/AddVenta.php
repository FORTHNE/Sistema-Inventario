<?php
require_once('../controllers/conexion.php');
include('../master/headerEmpl.php');
?>
<div class="container">
    <h3 class="text-center">NUEVA VENTA</h3>
    <hr>
</div>
<div class="container mt-5">
    <main>
        <div class="row">
            <div class="col-12">
               
                <div class="row justify-content-center align-content-center text-center">
                    
                    <form action="../controllers/addventa.php" method="POST">    
                        
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Seleccione su producto que desea adquirir:</label>
                            <select class="form-select" aria-label="Default select example" name="id_producto">
                                <option value="">Seleccione...</option>
                                    <?php
                                        $query="SELECT * FROM productos WHERE Estado='Disponible'";
                                        $result=mysqli_query($conexion, $query) or die (mysqli_error());
                                        while ($row=mysqli_fetch_array($result)){
                                        echo '<option value="'.$row['id_producto'].'">'.$row['nombre_producto'].' $'.$row['precio_unitario'].'</option>';
                                        }
                                    ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Cantidad de Productos:</label>
                            <input type="NUMBER" class="form-control" id="cantidad_producto" name="cantidad_producto" placeholder="Ingrese la cantidad de Productos" required>
                        </div> 

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Fecha del dia de ahora:</label>
                            <input type="date" class="form-control" id="fecha" name="fecha" placeholder="" required>
                        </div> 
                                    
                        <button type="submit" class="btn btn-primary">Generar Venta</button>
                        <a href="venta.php" class="btn btn-danger">Cancelar Venta</a>
                    </form>
                    
                    <?php
                        if(isset($_SESSION['message']))
                        {
                            echo "<h4>".$_SESSION['message']."</h4>";
                            unset($_SESSION['message']);
                        }
                    ?>

                </div>

            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>