<?php
error_reporting(0);
require_once('../controllers/conexion.php');
include('../master/header.php');

$Id_Usuario  = $_GET['Id_Usuario'];
$Nombre_Completo = $_GET['Nombre_Completo'];
$Correo = $_GET['Correo'];
$Clave = $_GET['Clave'];
$IdPrivilegio = $_GET['IdPrivilegio'];
$Estado = $_GET['Estado'];

?>

<div class="container">
    <main>
        <div class="row">
            <div class="text-center">
                <h5>ACTUALIZAR USUARIO</h5>
            </div>
           
            <div class="col-12">
                <div class="row justify-content-center align-content-center text-center">
                    
                    <form action="../controllers/editarusuario.php" method="POST">
                    <input type="text" class="form-control" id="Id_Usuario" name="Id_Usuario" placeholder="" style="visibility: hidden"; value="<?=$Id_Usuario?>" required>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Nombre del Usuario:</label>
                            <input type="text" class="form-control" id="Nombre_Completo" name="Nombre_Completo" placeholder="" value="<?=$Nombre_Completo?>" required>
                        </div> 
                        
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Correo Electronico:</label>
                            <input type="email" class="form-control" id="Correo" name="Correo" placeholder="" value="<?=$Correo?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Contraseña:</label>
                            <input type="password" class="form-control" id="Clave" name="Clave" placeholder="" value="<?=$Clave?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Seleccione su privilegio dentro de la empresa:</label>
                            <select class="form-select" aria-label="Default select example" name="IdPrivilegio">
                                    <?php
                                        $query="SELECT * FROM privilegios";
                                        $result=mysqli_query($conexion, $query) or die (mysqli_error());
                                        while ($row=mysqli_fetch_array($result)){
                                        echo '<option value="'.$row['id'].'">'.$row['privilegio'].'</option>';
                                        }
                                    ?>
                            </select>
                        </div> 

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Estado del Usuario:</label>
                            <select class="form-select" aria-label="Default select example" name="Estado">
                                <option value="Activo">Activo</option>
                                <option value="Inactivo">Inactivo</option>
                            </select>
                        </div>
                                    
                        <button type="submit" class="btn btn-primary">Actualizar Usuario</button>
                        <a href="usuario.php" class="btn btn-danger">Regresar</a>
                    </form>

                    <?php
                        if(isset($_SESSION['message']))
                        {
                            echo "<h4>".$_SESSION['message']."</h4>";
                            unset($_SESSION['message']);
                        }
                    ?>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>