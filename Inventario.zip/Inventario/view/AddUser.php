<?php
require_once('../controllers/conexion.php');
include('../master/header.php');
?>

<div class="container">
    <main>
        <div class="row">
            <div class="text-center">
                <h5>AGREGAR USUARIO</h5>
            </div>
           
            <div class="col-12">
                <div class="alert alert-info" role="alert">
                    <strong> * Todos los campos son obligatorios</strong> 
                </div>
                
                <div class="row justify-content-center align-content-center text-center">
                    
                    <form action="../controllers/adduser.php" method="POST">

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">* Escriba el nombre completo:</label>
                            <input type="text" class="form-control" id="Nombre_Completo" name="Nombre_Completo" placeholder="" required>
                        </div>     
                        
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label"> * Escriba su Correo:</label>
                            <input type="email" class="form-control" id="Correo" name="Correo" placeholder="" required>
                        </div> 

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label"> * Escriba una Contraseña segura:</label>
                            <input type="password" class="form-control" id="Clave" name="Clave" placeholder="" required>
                        </div> 

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label"> * Seleccione su privilegio dentro de la empresa:</label>
                            <select class="form-select" aria-label="Default select example" name="IdPrivilegio">
                                <option value="">Seleccione...</option>
                                    <?php
                                        $query="SELECT * FROM privilegios";
                                        $result=mysqli_query($conexion, $query) or die (mysqli_error());
                                        while ($row=mysqli_fetch_array($result)){
                                        echo '<option value="'.$row['id'].'">'.$row['privilegio'].'</option>';
                                        }
                                    ?>
                            </select>
                        </div> 

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label"> * Estado del Usuario:</label>
                            <select class="form-select" aria-label="Default select example" name="Estado">
                                <option selected>Seleccione...</option>
                                <option value="Activo">Activo</option>
                                <option value="Inactivo">Inactivo</option>
                            </select>
                        </div>
                                    
                        <button type="submit" class="btn btn-primary">Agregar Usuario</button>
                        <a href="usuario.php" class="btn btn-danger">Regresar</a>
                    </form>
                    
                    <?php
                        if(isset($_SESSION['message']))
                        {
                            echo "<h4>".$_SESSION['message']."</h4>";
                            unset($_SESSION['message']);
                        }
                    ?>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>