<?php
require_once('../controllers/conexion.php');
include('../master/header.php');
?>

<div class="container">
    <main>
        <div class="row">
            <div class="col-12">
                <div class="row justify-content-center align-content-center text-center">
                    
                    <div class="card">
                        <div class="card-header">
                            PROVEEDOR
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-secondary">
                                    <thead>
                                        <tr>
                                            <th scope="col">ID</th>
                                            <th scope="col">Nombre</th>
                                            <th scope="col">Direccion</th>
                                            <th scope="col">Telefono</th>
                                            <th scope="col">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                        $sql = "SELECT id_proveedor, nombre_proveedor, dirección, teléfono FROM proveedor";
                                        $rta = mysqli_query($conexion, $sql);
                                        while ($mostrar = mysqli_fetch_row($rta)){
                                    ?>
                                        <tr>
                                            <th> <?php echo $mostrar["0"] ?> </th>
                                            <td><?php echo $mostrar["1"] ?></td>
                                            <td><?php echo $mostrar["2"] ?></td>
                                            <td><?php echo $mostrar["3"] ?></td>
                                            <td>
                                                <a
                                                href="editsproveedor.php? 
                                                id_proveedor=<?php echo $mostrar['0'] ?> &
                                                nombre_proveedor=<?php echo $mostrar['1'] ?> &
                                                dirección=<?php echo $mostrar['2'] ?> &
                                                teléfono=<?php echo $mostrar['3'] ?> " 
                                                class="btn btn-success">Editar</a>
                                                <a href="../controllers/deleteprovee.php?id_proveedor=<?php echo $mostrar['0'] ?>" class="btn btn-danger">Eliminar</a>
                                            </td>    
                                        </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                            
                        </div>
                        <div class="card-footer text-muted">
                            <a href="AddProveedor.php" class="btn btn-primary">Nuevo</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>