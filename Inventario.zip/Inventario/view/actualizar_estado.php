<?php
require_once('../controllers/conexion.php');

// Obtener el ID de la fila a actualizar
$id_producto = $_GET['id_producto'];

// Actualizar el estado de la fila
mysqli_query($conexion, "UPDATE productos SET Estado = 'Terminado' WHERE id_producto = $id_producto");
header('Location: ../view/productos.php');
// Cerrar la conexión a la base de datos
mysqli_close($conexion);
?>