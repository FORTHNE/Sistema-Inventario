<?php
error_reporting(0);
require_once('../controllers/conexion.php');
include('../master/header.php');

$id_proveedor  = $_GET['id_proveedor'];
$nombre_proveedor = $_GET['nombre_proveedor'];
$dirección = $_GET['dirección'];
$teléfono = $_GET['teléfono'];

?>

<div class="container">
    <main>
        <div class="row">
            <div class="text-center">
                <h5>ACTUALIZAR PROVEEDOR</h5>
            </div>
           
            <div class="col-12">
                <div class="row justify-content-center align-content-center text-center">
                    
                    <form action="../controllers/editProveedor.php" method="POST">
                    <input type="text" class="form-control" id="id_proveedor" name="id_proveedor" placeholder="" style="visibility: hidden"; value="<?=$id_proveedor?>" required>
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Nombre del proveedor:</label>
                            <input type="text" class="form-control" id="nombre_proveedor" name="nombre_proveedor" placeholder="" value="<?=$nombre_proveedor?>" required>
                        </div> 
                        
                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Direccion:</label>
                            <input type="text" class="form-control" id="dirección" name="dirección" placeholder="" value="<?=$dirección?>" required>
                        </div>

                        <div class="mb-3">
                            <label for="formGroupExampleInput2" class="form-label">Numero Telefonico:</label>
                            <input type="text" class="form-control" id="teléfono" name="teléfono" placeholder="" value="<?=$teléfono?>" required>
                        </div>
                                    
                        <button type="submit" class="btn btn-primary">Actualizar Proveedor</button>
                        <a href="proveedor.php" class="btn btn-danger">Regresar</a>
                    </form>

                    <?php
                        if(isset($_SESSION['message']))
                        {
                            echo "<h4>".$_SESSION['message']."</h4>";
                            unset($_SESSION['message']);
                        }
                    ?>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>