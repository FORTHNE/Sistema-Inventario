<?php
require_once('../controllers/conexion.php');
include('../master/header.php');
?>

<div class="container">
    <main>
        <div class="row">
            <div class="col-100">
                <div class="row justify-content-center align-content-center text-center">
                    
                    <div class="card">
                        <div class="card-header">
                            PRODUCTOS
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-secondary">
                                    <thead>
                                        <tr>
                                            <th scope="col">ID</th>
                                            <th scope="col">Producto</th>
                                            <th scope="col">Cantidad Disponible</th>
                                            <th scope="col">Precio</th>
                                            <th scope="col">Proveedor</th>
                                            <th scope="col">Categoria</th>
                                            <th scope="col">Estado</th>
                                            <th scope="col">Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                        $sql = "SELECT productos.id_producto, productos.nombre_producto, productos.cantidad_disponible, productos.precio_unitario, proveedor.nombre_proveedor, categoria.Nombre_Categoria, productos.Estado FROM productos 
                                        INNER JOIN proveedor ON productos.proveedor_id=proveedor.id_proveedor 
                                        INNER JOIN categoria ON productos.Id_Categoria=categoria.Id_Categoria";
                                        $rta = mysqli_query($conexion, $sql);
                                        while ($mostrar = mysqli_fetch_row($rta)){
                                    ?>
                                        <tr>
                                            <th> <?php echo $mostrar["0"] ?> </th>
                                            <td><?php echo $mostrar["1"] ?></td>
                                            <td><?php echo $mostrar["2"] ?></td>
                                            <td><?php echo $mostrar["3"] ?></td>
                                            <td><?php echo $mostrar["4"] ?></td>
                                            <td><?php echo $mostrar["5"] ?></td>
                                            <td><?php echo $mostrar["6"] ?></td>
                                            <td>
                                                <a
                                                href="EditProducts.php? 
                                                id_producto=<?php echo $mostrar['0'] ?> &
                                                nombre_producto=<?php echo $mostrar['1'] ?> &
                                                cantidad_disponible=<?php echo $mostrar['2'] ?> &
                                                precio_unitario=<?php echo $mostrar['3'] ?> &
                                                proveedor_id=<?php echo $mostrar['4'] ?> &
                                                Id_Categoria=<?php echo $mostrar['5'] ?> &
                                                Estado=<?php echo $mostrar['6'] ?> " 
                                                class="btn btn-success">Editar</a>
                                                <a href="../controllers/deleteproductos.php?id_producto=<?php echo $mostrar['0'] ?>" class="btn btn-danger">Eliminar</a>
                                                <a href="../view/actualizar_estado.php?id_producto=<?php echo $mostrar['0'] ?>" class="btn btn-warning">Cambiar Estado</a>
                                                <a href="../view/activar.php?id_producto=<?php echo $mostrar['0'] ?>" class="btn btn-dark">Activar</a>
                                            </td>    
                                        </tr>
                                        <?php
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>

                            
                        </div>
                        <div class="card-footer text-muted">
                            <a href="AddProducto.php" class="btn btn-primary">Nuevo</a>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </main>
</div>

<?php
include('../master/footer.html');
?>