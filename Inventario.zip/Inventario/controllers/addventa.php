<?php
session_start();
require('conexion.php');

$id_producto = $_POST['id_producto'];
$cantidad_producto = $_POST['cantidad_producto'];
$fecha = $_POST['fecha'];


$id_producto = $_POST['id_producto'];
$cantidad_disponible = $_POST['cantidad_disponible'];

// Realizar consulta para obtener el stock actual del producto
$consultaStock = "SELECT cantidad_disponible FROM productos WHERE id_producto = $id_producto";
$resultadoStock = mysqli_query($conexion, $consultaStock);
$cantidad_disponible = mysqli_fetch_assoc($resultadoStock)['cantidad_disponible'];

// Verificar disponibilidad del producto
if ($cantidad_producto <= $cantidad_disponible) {
  // Actualizar el stock
  $nuevacantidad = $cantidad_disponible - $cantidad_producto;
  $consultaActualizarStock = "UPDATE productos SET cantidad_disponible = $nuevacantidad WHERE id_producto = $id_producto";
  mysqli_query($conexion, $consultaActualizarStock);

$sql = "INSERT INTO venta(id_producto, cantidad_producto, fecha) VALUES('$id_producto', '$cantidad_producto', '$fecha')";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    $_SESSION['message'] = "Error! Venta No Disponible o Producto Erroneo";
    header('Location: ../view/AddVenta.php');
}else{
    $_SESSION['message'] = "Exito! Venta Realizada Satisfactoriamente";
    header('Location: ../view/AddVenta.php');
}


}

?>