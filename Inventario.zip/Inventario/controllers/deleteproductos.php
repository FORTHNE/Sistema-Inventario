<?php
require('conexion.php');
$id_producto = $_GET['id_producto'];

$sql = "DELETE FROM productos where id_producto like $id_producto";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    echo '<script>alert("Error!");</script>';
}else{
    header("location: ../view/productos.php");
}

?>