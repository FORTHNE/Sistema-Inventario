<?php

$servidor="localhost";
$basedatos="inventario";
$usuario="root";
$clave="";

$conexion=mysqli_connect($servidor,$usuario,$clave,$basedatos);

if($conexion)
{
    
}
else
{
    echo'no existe';
}

    
?>