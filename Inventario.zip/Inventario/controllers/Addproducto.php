<?php
session_start();
require('conexion.php');

$nombre_producto = $_POST['nombre_producto'];
$cantidad_disponible = $_POST['cantidad_disponible'];
$precio_unitario = $_POST['precio_unitario'];
$proveedor_id = $_POST['proveedor_id'];
$Id_Categoria = $_POST['Id_Categoria'];
$Estado = $_POST['Estado'];

$sql = "INSERT INTO productos(nombre_producto, cantidad_disponible, precio_unitario, proveedor_id, Id_Categoria, Estado) VALUES('$nombre_producto', '$cantidad_disponible', '$precio_unitario', '$proveedor_id', '$Id_Categoria', '$Estado')";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    $_SESSION['message'] = "Error!";
    header('Location: ../view/AddProducto.php');
}else{
    $_SESSION['message'] = "Exito! Dato Guardado";
    header('Location: ../view/AddProducto.php');
}

?>