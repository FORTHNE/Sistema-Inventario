<?php
error_reporting(0);
require('conexion.php');

session_start();
$Correo=$_POST['Correo'];
$Clave=$_POST['Clave'];
$_SESSION['Correo']=$Correo;

$consulta="SELECT * FROM usuario where Correo='$Correo' and Clave='$Clave' and Estado = 'Activo'";


$resultado=mysqli_query($conexion,$consulta);

$filas=mysqli_fetch_array($resultado);

if($filas['IdPrivilegio']==1){
header('location:../view/categorias.php');
}
else
if($filas['IdPrivilegio']==2){
header('location:../view/venta.php');
}
else
{
?>
<?php
include("index.php");
?>
<h1 class="bad">Error en la autenticacion</h1>
<?php
}
mysqli_free_result($resultado);
mysqli_close($conexion);
?>