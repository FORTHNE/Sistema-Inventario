<?php
require('conexion.php');
$id_venta = $_GET['id_venta'];

$sql = "DELETE FROM venta where id_venta like $id_venta";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    echo '<script>alert("Error! Venta Denegada");</script>';
}else{
    header("location: ../view/contabilidad.php");
}

?>