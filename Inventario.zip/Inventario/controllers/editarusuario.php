<?php

session_start();
require('conexion.php');

$Id_Usuario  = $_POST['Id_Usuario'];
$Nombre_Completo = $_POST['Nombre_Completo'];
$Correo = $_POST['Correo'];
$Clave = $_POST['Clave'];
$IdPrivilegio = $_POST['IdPrivilegio'];
$Estado = $_POST['Estado'];

$sql = "UPDATE usuario SET Nombre_Completo='$Nombre_Completo', Correo='$Correo', Clave='$Clave', IdPrivilegio='$IdPrivilegio', Estado='$Estado' WHERE Id_Usuario like $Id_Usuario";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    $_SESSION['message'] = "Error!";
    header('Location: ../view/EditUser.php');
}else{
    $_SESSION['message'] = "Exito! Dato Actualizado";
    header('Location: ../view/EditUser.php');
}
?>