<?php

session_start();
require('conexion.php');

$id_producto = $_POST['id_producto'];
$nombre_producto = $_POST['nombre_producto'];
$cantidad_disponible = $_POST['cantidad_disponible'];
$precio_unitario = $_POST['precio_unitario'];
$proveedor_id = $_POST['proveedor_id'];
$Id_Categoria = $_POST['Id_Categoria'];
$Estado = $_POST['Estado'];

$sql = "UPDATE productos SET nombre_producto='$nombre_producto', cantidad_disponible='$cantidad_disponible', precio_unitario='$precio_unitario', proveedor_id='$proveedor_id', Id_Categoria='$Id_Categoria', Estado='$Estado' WHERE id_producto like $id_producto";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    $_SESSION['message'] = "Error!";
    header('Location: ../view/EditProducts.php');
}else{
    $_SESSION['message'] = "Exito! Dato Actualizado";
    header('Location: ../view/EditProducts.php');
}
?>