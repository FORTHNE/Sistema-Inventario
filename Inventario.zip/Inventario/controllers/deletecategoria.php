<?php
require('conexion.php');
$Id_Categoria = $_GET['Id_Categoria'];

$sql = "DELETE FROM categoria where Id_Categoria like $Id_Categoria";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    echo '<script>alert("Error!");</script>';
}else{
    header("location: ../view/categorias.php");
}

?>