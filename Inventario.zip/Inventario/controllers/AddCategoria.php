<?php
session_start();
require('conexion.php');

$Nombre_Categoria = $_POST['Nombre_Categoria'];

$sql = "INSERT INTO categoria(Nombre_Categoria) VALUES('$Nombre_Categoria')";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    $_SESSION['message'] = "Error!";
    header('Location: ../view/Addcategoria.php');
}else{
    $_SESSION['message'] = "Exito! Dato Guardado";
    header('Location: ../view/Addcategoria.php');
}

?>