<?php
session_start();
require('conexion.php');

$id_proveedor = $_POST['id_proveedor'];
$nombre_proveedor = $_POST['nombre_proveedor'];
$dirección = $_POST['dirección'];
$teléfono = $_POST['teléfono'];

$sql = "UPDATE proveedor SET nombre_proveedor='$nombre_proveedor', dirección='$dirección', teléfono='$teléfono' WHERE id_proveedor like $id_proveedor";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    $_SESSION['message'] = "Error!";
    header('Location: ../view/editsproveedor.php');
}else{
    $_SESSION['message'] = "Exito! Dato Guardado";
    header('Location: ../view/editsproveedor.php');
}

?>