<?php

session_start();
require('conexion.php');

$Id_Categoria = $_POST['Id_Categoria'];
$Nombre_Categoria = $_POST['Nombre_Categoria'];

$sql = "UPDATE categoria SET Nombre_Categoria='$Nombre_Categoria' WHERE Id_Categoria like $Id_Categoria";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    $_SESSION['message'] = "Error!";
    header('Location: ../view/EditCategoria.php');
}else{
    $_SESSION['message'] = "Exito! Dato Actualizado";
    header('Location: ../view/EditCategoria.php');
}
?>