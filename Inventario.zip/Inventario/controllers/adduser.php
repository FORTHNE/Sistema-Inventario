<?php
session_start();
require('conexion.php');

$Nombre_Completo = $_POST['Nombre_Completo'];
$Correo = $_POST['Correo'];
$Clave = $_POST['Clave'];
$IdPrivilegio  = $_POST['IdPrivilegio'];
$Estado  = $_POST['Estado'];

$sql = "INSERT INTO usuario(Nombre_Completo, Correo, Clave, IdPrivilegio, Estado) VALUES('$Nombre_Completo', '$Correo', '$Clave', '$IdPrivilegio', '$Estado')";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    $_SESSION['message'] = "Error!";
    header('Location: ../view/AddUser.php');
}else{
    $_SESSION['message'] = "Exito! Dato Guardado";
    header('Location: ../view/AddUser.php');
}

?>