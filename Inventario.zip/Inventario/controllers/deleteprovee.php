<?php
require('conexion.php');
$id_proveedor = $_GET['id_proveedor'];

$sql = "DELETE FROM proveedor where id_proveedor like $id_proveedor";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    echo '<script>alert("Error!");</script>';
}else{
    header("location: ../view/proveedor.php");
}

?>