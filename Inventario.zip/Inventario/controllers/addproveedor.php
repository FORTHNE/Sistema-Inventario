<?php
session_start();
require('conexion.php');

$nombre_proveedor = $_POST['nombre_proveedor'];
$dirección = $_POST['dirección'];
$teléfono = $_POST['teléfono'];

$sql = "INSERT INTO proveedor(nombre_proveedor, dirección, teléfono) VALUES('$nombre_proveedor', '$dirección', '$teléfono')";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    $_SESSION['message'] = "Error!";
    header('Location: ../view/AddProveedor.php');
}else{
    $_SESSION['message'] = "Exito! Dato Guardado";
    header('Location: ../view/AddProveedor.php');
}

?>