<?php
require('conexion.php');
$Id_Usuario = $_GET['Id_Usuario'];

$sql = "DELETE FROM usuario where Id_Usuario like $Id_Usuario";
$rta = mysqli_query($conexion, $sql);
if(!$rta){
    echo '<script>alert("Error!");</script>';
}else{
    header("location: ../view/usuario.php");
}

?>