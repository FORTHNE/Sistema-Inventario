<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>login</title>
    <link rel="stylesheet" href="css/login.css">
    <link rel="stylesheet" href="css/cabecera.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css">
</head>
<body>
   <form action="./controllers/validar.php" method="POST">
    <img src="img/logo.png" class="avatar" alt="Avatar">
   <h1 class="animate__animated animate__backInLeft">INVENTARIO SAN FRANCISCO</h1>

   <p>Correo:<input type="text"  id="username" placeholder="ingrese su correo" name="Correo" required></p>
   
   <p>Contraseña:<input type="password"  id="password" placeholder="ingrese su contraseña" name="Clave" required></p>
   

   <p id="errorMessage" hidden></p>
   <input type="submit" id="submit" value="Ingresar" >
   
   </form> 

   
</body>
</html>